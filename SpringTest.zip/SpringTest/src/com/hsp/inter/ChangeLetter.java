package com.hsp.inter;

public interface ChangeLetter {

	public String change();
}
